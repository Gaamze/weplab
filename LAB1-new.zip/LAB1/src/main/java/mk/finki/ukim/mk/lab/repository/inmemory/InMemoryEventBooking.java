package mk.finki.ukim.mk.lab.repository.inmemory;

public class InMemoryEventBooking {
}
// inmemi= kullanili ramda
//jpa =api  data persistent kalici oliler. mysql de buluniler